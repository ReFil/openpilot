const uint8_t gitversion[] = "DEV-931fb528-DEBUG";
